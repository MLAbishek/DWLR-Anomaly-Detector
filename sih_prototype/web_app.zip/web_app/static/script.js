document.addEventListener('DOMContentLoaded', function () {
    // Initialize map
    const map = new maplibregl.Map({
        container: 'map-container',
        style: 'https://api.maptiler.com/maps/streets/style.json?key=lvOABT6fHkPafe0i4055',
        center: [78.9629, 20.5937], // Center of India
        zoom: 4
    });

    // Fetch DWLR data from the backend
    fetch('/get_dwlr_data')
        .then(response => response.json())
        .then(dwlrData => {
            // Add markers for each DWLR
            dwlrData.forEach(dwlr => {
                const el = document.createElement('div');
                el.className = 'marker';
                el.style.backgroundColor = getColorForWaterLevel(dwlr.water_level);
                el.style.width = '20px';
                el.style.height = '20px';
                el.style.borderRadius = '50%';

                new maplibregl.Marker(el)
                    .setLngLat([dwlr.lng, dwlr.lat])
                    .setPopup(new maplibregl.Popup().setHTML(`
                        <h3>DWLR at ${dwlr.lat.toFixed(4)}, ${dwlr.lng.toFixed(4)}</h3>
                        <p>Water Level: ${dwlr.water_level.toFixed(2)} m</p>
                        <p>Temperature: ${dwlr.temperature.toFixed(1)} °C</p>
                        <p>Rainfall: ${dwlr.rainfall.toFixed(1)} mm</p>
                        <p>pH: ${dwlr.ph.toFixed(2)}</p>
                        <p>Dissolved Oxygen: ${dwlr.dissolved_oxygen.toFixed(2)} mg/L</p>
                        <p>Last Updated: ${new Date(dwlr.timestamp).toLocaleString()}</p>
                    `))
                    .addTo(map);
            });
        })
        .catch(error => console.error('Error fetching DWLR data:', error));

    // Function to determine color based on water level
    function getColorForWaterLevel(level) {
        if (level < 2) return '#2ecc71'; // Low - Green
        if (level < 3) return '#f1c40f'; // Medium - Yellow
        if (level < 4) return '#e67e22'; // High - Orange
        return '#e74c3c'; // Very High - Red
    }

    // Handle form submission
    document.getElementById('telemetryForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = {
            timestamp: document.getElementById('timestamp').value,
            water_level: parseFloat(document.getElementById('water_level').value),
            temperature: parseFloat(document.getElementById('temperature').value),
            rainfall: parseFloat(document.getElementById('rainfall').value),
            ph: parseFloat(document.getElementById('ph').value),
            dissolved_oxygen: parseFloat(document.getElementById('dissolved_oxygen').value),
            latitude: parseFloat(document.getElementById('latitude').value),
            longitude: parseFloat(document.getElementById('longitude').value)
        };

        fetch('/submit_telemetry', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        })
            .then(response => response.json())
            .then(data => {
                const messageElement = document.getElementById('message');
                messageElement.textContent = data.message;
                messageElement.className = data.message.includes('Anomaly') ? 'error' : 'success';

                // Clear form after successful submission
                e.target.reset();

                // Refresh the map data
                location.reload();
            })
            .catch((error) => {
                console.error('Error:', error);
                const messageElement = document.getElementById('message');
                messageElement.textContent = 'An error occurred. Please try again.';
                messageElement.className = 'error';
            });
    });
});